from django.contrib import admin
from .models import Upload

#admin.site.register(Post)
admin.site.register(Upload)
