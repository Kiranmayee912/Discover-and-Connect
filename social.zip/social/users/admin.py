from django.contrib import admin
from .models import Profile,Friend,Interest
admin.site.register(Friend)
admin.site.register(Profile)
admin.site.register(Interest)