SportsChoices=(
    ('Cricket', 'Cricket'),
    ('FootBall','FootBall'),
    ('Tennis','Tennis'),
    ('Kabaddi','Kabaddi'),
    ('Others','Others')
)

FoodChoices=(
    ('Indian','Indian'),
    ('Chinese','Chinese'),
    ('Italian','Italian'),
    ('Continental','Continental'),
    ('Others', 'Others')
)

MovieChoices=(
    ('Hollywood','Hollywood'),
    ('Bollywood','Bollywood'),
    ('Tollywood','Tollywood'),
    ('Kollywood','Kollywood'),
    ('Others','Others')
)

MusicChoices=(
    ('Classical','Classical'),
    ('Pop','Pop'),
    ('Country','Country'),
    ('Folk','Folk'),
    ('Others','Others')
)